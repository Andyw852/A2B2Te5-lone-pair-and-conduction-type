﻿A2B2Te5（A = Pb, Sn；B = Sb, Bi）中的孤对电子与导电类型：论文写作用报告与数据
生成日期 2026-10-28。全部为理论计算；实验 S(T) 为从所给曲线图读取的近似值。
结构：问题一（PBE、HSE 能带与 S）用所给的四种 9 原子层状结构。问题二只算 Pb2Sb2Te5，用了三套缺陷计算：
D（无序立方）、O（有序立方）为 144 原子岩盐超胞；L 为所给层状结构的 3×3×1 超胞（81 原子，早先一批）。见报告 1.1 节、图 1、表 1。

A2B2Te5_report.html    报告正文（用浏览器打开；图片从 figures/png 读取，请先整体解压再打开）
A2B2Te5_report_单文件.html  同一报告，图片已嵌入，单独打开或转发都能显示
figures/png/           图 1–8，600 dpi PNG（文件名的 FigN 即正文的图 N）
figures/pdf/           图 1–8，矢量 PDF（字体已嵌入，英文 Times New Roman，公式 STIX）
data/                  每幅图的源数据，即图中画出的数值，目录名与图文件名对应
  Fig1_structures/            O、D 两个 144 原子母胞的格点占位（每个格点的原子面、种类、坐标）与未弛豫 POSCAR；
                              所给的 9 原子层状结构 POSCAR（问题一的能带与 S 都用它）；图 1c、d 各原子面的高度与堆垛位置；
                              三种结构的晶格、体积与能量对比（structure_comparison.csv，即表 1）
  Fig2_bands_PBE_vs_HSE/      四种材料 PBE+SOC、HSE06+SOC 的路径能带（相对价带顶，eV），路径带隙
  Fig3_HSE_bands_cation_s/    HSE06+SOC 路径能带及每个 k 点、每条带的阳离子 s 成分（%）
  Fig4_lone_pair_valley/      最高孤对电子价带谷相对价带顶的能量（meV）、所在 k 点与成分
  Fig5_Seebeck/               300 K、3×10^19 cm^-3 的面内 S：PBE+SOC（BoltzTraP2）与 HSE 估计；表 4 的逐谷电导份额
                              （valley_conductivity_shares.csv：每个谷的位置、离带边能量、阳离子 s 成分、份额；lone_pair_share_summary.csv：汇总）
  Fig6_S_vs_T/                实验 S(T)、计算 S(T)（HSE 与 PBE 能带）、拟合浓度与最大偏差
  Fig7_formation_energies/    12 类缺陷逐位点的中性形成能（富 Te、贫 Te），两端化学势
  Fig8_ordering/              有序化引起的形成能变化 ΔE_f = E_f(O) − E_f(D)，逐位点与中位数
  L_layered_defects/          早先一批在所给层状结构上（3×3×1，81 原子）的缺陷计算，即正文表 7、表 8 的 L 列：
                              L_defect_ranking_all_vertices.csv  5 个化学势顶点下全部缺陷在平衡费米能级处的形成能排名
                              L_formation_energy_results.json    原始结果（各电荷态的形成能、转变能级、化学势、载流子浓度）
  tables/                     正文表格：
      Table1_structures.csv    表 1 本工作用到的三种 Pb₂Sb₂Te₅ 结构。能量与体积为 PBE-D3、不含 SOC，与缺陷计算用同一设置。
      Table2_band_gaps_and_edges.csv    表 2 路径带隙与带边位置。
      Table3_HSE_band_edges.csv    表 3 HSE06+SOC 的带边：位置、主质量（单位 m_e）与轨道成分。
      Table4_Seebeck_300K.csv    表 4 300 K 面内 Seebeck 系数（µV/K；箭头左边为 PBE + BoltzTraP2，右边为 HSE 估计，* 为暂定值）与孤对电子态承担的电导份额（HSE，3×10¹⁹ cm⁻³，300 K）。份额 = 1.7 节多谷模型中该类谷对面内电导的贡献 ÷ 总电导（含少数载流子）；p 型计入极值点处阳离子 s ≥ 15% 的价带谷，n 型计入 Γ 处（Sn₂Sb₂Te₅ 为紧邻 Γ 的 Γ–A 驼峰）的导带谷。逐谷数值见 data/Fig5_Seebeck/valley_conductivity_shares.csv。
      Table5_S_T_fit.csv    表 5 实验 S(T) 的对照：拟合出的净载流子浓度，以及 300–620 K 全程的最大偏差（计算 − 实验，µV/K）。
      Table6_lowest_formation_energies.csv    表 6 各类缺陷最低位点的中性形成能（eV），按从低到高排列；括号内为名义电荷。
      Table7_defects_D_O_L.csv    表 7 三种结构中各类缺陷最低位点的中性形成能（eV）。D、O 取富 Te 端；L 取早先计算的富 Te 顶点 v0，其计算设置与 D、O 不同，只比较排序与量级（1.5 节）。括号内为名义电荷。
      Table8_conduction_type.csv    表 8 退火前后的主导缺陷与导电类型。

约定：能量单位 eV（另注明者除外），S 单位 µV/K，载流子浓度单位 cm^-3（正为空穴、负为电子），
k 点坐标为倒格矢分数坐标；能带 CSV 中 band_N 为 VASP 能带序号（SOC，_VB_top 为价带顶，_CB_bottom 为导带底）。
CSV 为 UTF-8（带 BOM），可直接用 Excel、Origin 打开。

生成脚本（在仓库中）：10_脚本/paper_figures.py（图与源数据）、10_脚本/multivalley_seebeck.py（S 的模型）、
10_脚本/build_paper_report.py（本压缩包）。
