﻿A2B2Te5（A = Pb, Sn；B = Sb, Bi）中的孤对电子与导电类型：论文写作用报告与数据
生成日期 2026-10-28，2026-11-05 整合版：HSE06+SOC 能带专题并入本报告；HSE06+SOC 与 PBE+SOC 的 S 都是同一 28×28×7/6 网格上
BoltzTraP2 的直接计算（不加剪刀）；新增 COHP（图 3-2）。改动见报告文首的版本说明。计算全部为理论计算；实验 S(T)、σ(T) 与室温霍尔为用户提供的实验值。
结构：问题一（能带、COHP 与 S）用所给的四种 9 原子层状结构。问题二只算 Pb2Sb2Te5，用了三套缺陷计算：
D（无序立方）、O（有序立方）为 144 原子岩盐超胞；L 为所给层状结构的 3×3×1 超胞（81 原子，早先一批）。见报告 1.1 节、图 1、表 1。

A2B2Te5_report.html    报告正文（用浏览器打开；图片从 figures/png 读取，请先整体解压再打开）
A2B2Te5_report_单文件.html  同一报告，图片已嵌入，单独打开或转发都能显示
figures/png/           全部图，600 dpi PNG（文件名的 FigN、FigN-1、FigN-2 即正文的图 N、N-1、N-2）
figures/pdf/           同上，矢量 PDF（字体已嵌入，英文 Times New Roman，公式 STIX）
                       输运图都分两幅：“-1”只画 HSE06+SOC，“-2”为 HSE06+SOC 与 PBE+SOC 对比（图 8、9、10）
作图数据/<类别>/       每幅图单独一个 Excel（文件名同 data/ 下的图目录名；第一页“说明”写明每个子图用哪一页、横轴纵轴取哪一列，
                       其后每个数据表一页，数值为数字格式，可直接在 Excel、Origin 中作图）；正文表格在 06_正文表格/tables.xlsx
data/作图数据索引.csv  同一份索引的 CSV（全部图）
data/<类别>/<图目录>/   每幅图的源数据，即图中画出的数值，图目录名与图文件名对应。类别：
                       01_结构（图 1）；02_能带与轨道成分（图 2-1 至 5、S2、S3）；03_价带谷与口袋（图 6-1、6-2、7、S1）；
                       04_输运与实验对照（图 8-1 至 10-2、表 6–8）；05_缺陷与导电类型（图 11、12，L 层状相缺陷）；06_正文表格（表 1–11）
                       下面按图目录逐个说明（能量相对真实价带顶，另注明者除外）：
  01_结构/
  Fig1_structures/            O、D 两个 144 原子母胞的格点占位与未弛豫 POSCAR；所给的 9 原子层状结构 POSCAR；
                              图 1c、d 各原子面的高度与堆垛位置；三种结构的晶格、体积与能量对比（structure_comparison.csv，即表 1）
  02_能带与轨道成分/
  Fig2-1_HSE_bands/           HSE06+SOC 路径能带；Sn 系的附加路径 Γ–Σ′–R₂′–L（*_true_valley_path_G-S-R2-L.csv）；真实带隙与路径带隙
  Fig2-2_bands_PBE_vs_HSE/    PBE+SOC、HSE06+SOC 的路径能带（各相对本泛函的价带顶）；路径带隙及 Γ 处能级与反转带隙（band_gaps_on_path.csv）
  Fig3-1_HSE_bands_cation_s/  HSE06+SOC 路径能带及每个 k 点、每条带的阳离子 s 成分（%）；Sn 系的附加路径
  Fig3-2_COHP/                最短 A–Te、B–Te 键的轨道分辨 −COHP（阳离子 s–Te p、阳离子 p–Te p、总和；正为成键，PBE、不加 SOC，COGITO）；
                              ICOHP（积分到 E_F 与价带顶以下 1 eV 内，ICOHP_summary.csv，正为反键）
  Fig4-1_cation_s_by_atom/    HSE06+SOC 路径能带上每个 k 点、每条带的 A（Pb/Sn）、B（Sb/Bi）、Te 的 s 成分（%）；关键态（表 4）
  Fig4-2_HSE_orbitals/        HSE06+SOC 路径能带上的 A 位 s、B 位 s、A 位 p、B 位 p、Te p 成分（图 4-2 与图 S3a–d 共用）
  Fig5_SnSb_vs_SnBi/          Sn2Sb2Te5 与 Sn2Bi2Te5 的轨道投影、价带谷、价带能级（levels_true.csv 为真实值；其余相对路径价带顶）、
                              Γ 处最高价带与最低导带的能量与成分（表 5）
  FigS2_Gamma_levels_SOC/     Γ 点能级（PBE，有、无 SOC）与 Sb → Bi 变化的标量 / SOC 拆分（10_脚本/soc_mechanism.py）
  03_价带谷与口袋/
  Fig6-1_valence_levels/      四种材料价带上的谷：能量、等价口袋数、k、阳离子 s、主轴有效质量（HSE06+SOC）
  Fig6-2_pockets_BZ/          Sn 系全部价带口袋在布里渊区中的位置（pocket_positions.csv：每个口袋一行）
  Fig7_lone_pair_valley/      最高孤对电子价带谷相对价带顶的能量（meV）、所在 k 点与成分（两种泛函）
  FigS1_mirror_plane/         Sn 系镜面内最高价带的能量网格（meV）；路径上的谷与真实极大；两者的能量差（path_vs_true_maxima.csv）
  04_输运与实验对照/          （BoltzTraP2：HSE06+SOC 与 PBE+SOC，同一 28×28×7/6 网格，不加剪刀，常数弛豫时间）
  Fig8-1_Seebeck_HSE/         300 K 面内 S 随载流子浓度（HSE06+SOC）
  Fig8-2_Seebeck_HSE_vs_PBE/  同上，两种泛函（按 functional 列区分）
  Table6_S_300K/              表 6：300 K、±3×10¹⁹ 与 ±1×10²⁰ cm⁻³ 的 S
  Fig9-1_S_vs_T_HSE/          四个样品的实验 T、σ（S/m）、S 与室温霍尔；霍尔浓度下直接计算的 S(T)（HSE06+SOC，不调参数）
  Fig9-2_S_vs_T_HSE_vs_PBE/   同上，计算含两种泛函
  Table7_S_T_at_Hall/         表 7：最低、最高测量温度的实验与计算值，300–620 K 的均方根偏差
  Table8_Pisarenko_mass/      表 8（不作图）：样品的霍尔浓度、实验 S，同一浓度下 HSE、PBE 的 S，以及由此读出的态密度有效质量
  Fig10-1_Fermi_window_HSE/   300 K 的化学势 µ（霍尔浓度与 3×10¹⁹ cm⁻³，HSE06+SOC；µ 取自 BoltzTraP2，用 Γ 处本征值对齐到能带路径）
  Fig10-2_Fermi_window_HSE_vs_PBE/  两种泛函各自在霍尔浓度下的 µ
  05_缺陷与导电类型/
  Fig11_formation_energies/   12 类缺陷逐位点的中性形成能（富 Te、贫 Te），两端化学势
  Fig12_ordering/             有序化引起的形成能变化 ΔE_f = E_f(O) − E_f(D)，逐位点与中位数
  L_layered_defects/          早先一批在所给层状结构上（3×3×1，81 原子）的缺陷计算，即正文表 9、表 10 的 L 列：
                              L_defect_ranking_all_vertices.csv  5 个化学势顶点下全部缺陷在平衡费米能级处的形成能排名
                              L_formation_energy_results.json    原始结果（各电荷态的形成能、转变能级、化学势、载流子浓度）
  06_正文表格/
  tables/                     正文表格：
      Table1_structures.csv    表 1 本工作用到的三种 Pb₂Sb₂Te₅ 结构（PBE-D3，不含 SOC）。
      Table2_band_gaps_and_edges.csv    表 2 带隙与带边位置。Pb 系为能带路径上的值。Sn 系的价带顶在路径外时，HSE 取镜面内三维搜索的结果，PBE 取附加路径 Γ–Σ′–R₂′–L 上的最高点（1.2 节），带隙为真实值，括号内为路径值。
      Table3_HSE_band_edges.csv    表 3 HSE06+SOC 的带边：位置、主质量（面内两向 / 沿 c，单位 m_e）与轨道成分。
      Table4_s_by_atom.csv    表 4 关键态的 s 成分按原子拆分（%，HSE06+SOC）。孤对电子价带谷为图 7 中最高的那个；Sn 系的 Σ′、R₂′ 在路径外，成分取自附加路径 Γ–Σ′–R₂′–L 上的这一点。
      Table5_SnSb_vs_SnBi_valleys.csv    表 5 Sn₂Sb₂Te₅ 与 Sn₂Bi₂Te₅ 中 Γ 处最低导带态与价带顶附近各态的能量（相对各自的路径价带顶，meV）与主要成分（%），均为能带路径上的点。前两行之差即 Γ 处的反转带隙。Sn₂Bi₂Te₅ 的真实价带顶在路径外，比路径价带顶高 37.6 meV（1.2 节）。
      Table6_Seebeck_300K.csv    表 6 300 K 面内 S（µV/K）：HSE06+SOC 与 PBE+SOC + BoltzTraP2（同一 28×28×7/6 网格，不加剪刀）。
      Table7_S_T_at_Hall_conc.csv    表 7 霍尔浓度下的 S（µV/K）：实验、HSE06+SOC、PBE+SOC，最低与最高测量温度，以及 300–620 K 的均方根偏差。
      Table8_Pisarenko_mass.csv    表 8 由 300 K 的 S 与霍尔浓度读出的态密度有效质量 m*（单抛物带、声学声子散射，单位 m_e）。计算列：在霍尔浓度下用 HSE06+SOC 或 PBE+SOC + BoltzTraP2 算出 S，再用同样的方法读出 m*，与实验同口径。参照列为 HSE06+SOC 能带上单个谷的态密度质量（由能带曲率拟合）。
      Table9_lowest_formation_energies.csv    表 9 D、O 中各类缺陷最低位点的中性形成能（eV），从低到高排列；括号内为名义电荷。
      Table10_defects_D_O_L.csv    表 10 三种结构中各类缺陷的最低中性形成能（eV）。D、O 取富 Te 端，L 取富 Te 顶点；L 的计算设置不同，只比较排序与量级。
      Table11_conduction_type.csv    表 11 退火前后的主导缺陷与导电类型。

约定：能量单位 eV（另注明者除外），S 单位 µV/K，载流子浓度单位 cm^-3（正为空穴、负为电子），
k 点坐标为倒格矢分数坐标；谷的名称为所在高对称点或高对称线的标准记号（Σ：Γ–M，R：A–L，Δ：Γ–A，Λ：Γ–K，
Q：A–H，T：M–K；同一条线上的几个谷按离 Γ–A 轴由近到远加下标，如 R₁、R₂），见报告 1.2 节；能带 CSV 中 band_N 为 VASP 能带序号（SOC，_VB_top 为价带顶，_CB_bottom 为导带底）。
CSV 为 UTF-8（带 BOM），可直接用 Excel、Origin 打开。

生成脚本（在仓库中）：10_脚本/paper_figures.py（图与源数据；输运图 transport_figures.py，HSE 能带与轨道图 hse_band_figures.py，
COHP 提取 cohp_extract.py）；BoltzTraP2 结果 22_能带基准_1-0/<材料>/c8_hse_dense/gene/bt2_mult60/（HSE06+SOC）、
22_能带基准_1-0/bt2_pbe_dense/（PBE+SOC）；10_脚本/build_paper_report.py（本压缩包）。
