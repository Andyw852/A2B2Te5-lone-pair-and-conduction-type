﻿A2B2Te5（A = Pb, Sn；B = Sb, Bi）中的孤对电子与导电类型：论文写作用报告与数据
生成日期 2026-10-28。全部为理论计算；实验 S(T) 为用户提供的实验值。
结构：问题一（PBE、HSE 能带与 S）用所给的四种 9 原子层状结构。问题二只算 Pb2Sb2Te5，用了三套缺陷计算：
D（无序立方）、O（有序立方）为 144 原子岩盐超胞；L 为所给层状结构的 3×3×1 超胞（81 原子，早先一批）。见报告 1.1 节、图 1、表 1。

A2B2Te5_report.html    报告正文（用浏览器打开；图片从 figures/png 读取，请先整体解压再打开）
A2B2Te5_report_单文件.html  同一报告，图片已嵌入，单独打开或转发都能显示
figures/png/           图 1–11，600 dpi PNG（文件名的 FigN 即正文的图 N）
figures/pdf/           图 1–11，矢量 PDF（字体已嵌入，英文 Times New Roman，公式 STIX）
data/                  每幅图的源数据，即图中画出的数值，目录名与图文件名对应
  Fig1_structures/            O、D 两个 144 原子母胞的格点占位（每个格点的原子面、种类、坐标）与未弛豫 POSCAR；
                              所给的 9 原子层状结构 POSCAR（问题一的能带与 S 都用它）；图 1c、d 各原子面的高度与堆垛位置；
                              三种结构的晶格、体积与能量对比（structure_comparison.csv，即表 1）
  Fig2_bands_PBE_vs_HSE/      四种材料 PBE+SOC、HSE06+SOC 的路径能带（相对价带顶，eV）；路径带隙及 Γ 处最高价带、
                              最低导带的能量与反转带隙（band_gaps_on_path.csv）
  Fig3_HSE_bands_cation_s/    HSE06+SOC 路径能带及每个 k 点、每条带的阳离子 s 成分（%）
  Fig4_cation_s_by_atom/      HSE06+SOC 路径能带上每个 k 点、每条带的 A（Pb/Sn）、B（Sb/Bi）、Te 的 s 成分（%）；关键态（表 4）
  Fig5_SnSb_vs_SnBi/          Sn2Sb2Te5 与 Sn2Bi2Te5 路径能带上的 Sn-s、B-s、Sn-p、B-p、Te-p 投影；Γ 单谷与三组孤对电子谷的能量与成分；
                              Γ 处最高价带与最低导带的能量与成分（Gamma_states.csv）（表 5）
  Fig6_valence_pockets/       Sn2Sb2Te5、Sn2Bi2Te5 价带口袋在布里渊区中的位置（pocket_positions.csv：每个口袋一行，
                              分数坐标、笛卡尔坐标、所在面、能量、等价口袋数）；四种材料的价带能级（levels_HSE.csv）与谷间能量差（HSE06+SOC）
                              ΔE = E(Σ 孤对电子谷) − E(Γ–A 轴上最高价带态)（valley_offset_HSE.csv）
  Fig7_lone_pair_valley/      最高孤对电子价带谷相对价带顶的能量（meV）、所在 k 点与成分
  Fig8_Seebeck/               300 K、3×10^19 cm^-3 的面内 S：PBE+SOC（BoltzTraP2）与 HSE 估计；表 6 的逐谷电导份额
                              （valley_conductivity_shares.csv：每个谷的位置、离带边能量、阳离子 s 成分、份额；lone_pair_share_summary.csv：汇总）
                              lone_pair_share_vs_concentration.csv：孤对电子谷份额随空穴浓度的变化；
                              Sn2Bi2Te5_c3_valley_check.csv：SnBi 价带谷 c3 拟合的梯度、主质量、驻点位移与是否采用
  Fig9_S_vs_T/                实验 S(T)、计算 S(T)（HSE 与 PBE 能带）、拟合浓度与最大偏差
  Fig10_formation_energies/   12 类缺陷逐位点的中性形成能（富 Te、贫 Te），两端化学势
  Fig11_ordering/             有序化引起的形成能变化 ΔE_f = E_f(O) − E_f(D)，逐位点与中位数
  L_layered_defects/          早先一批在所给层状结构上（3×3×1，81 原子）的缺陷计算，即正文表 9、表 10 的 L 列：
                              L_defect_ranking_all_vertices.csv  5 个化学势顶点下全部缺陷在平衡费米能级处的形成能排名
                              L_formation_energy_results.json    原始结果（各电荷态的形成能、转变能级、化学势、载流子浓度）
  tables/                     正文表格：
      Table1_structures.csv    表 1 本工作用到的三种 Pb₂Sb₂Te₅ 结构（PBE-D3，不含 SOC）。
      Table2_band_gaps_and_edges.csv    表 2 路径带隙与带边位置。* Sn₂Bi₂Te₅ 的价带顶是离轴谷，真实极大在路径之外，路径带隙是上限（第 4 节）。
      Table3_HSE_band_edges.csv    表 3 HSE06+SOC 的带边：位置、主质量（面内两向 / 沿 c，单位 m_e）与轨道成分。
      Table4_s_by_atom.csv    表 4 关键态的 s 成分按原子拆分（%，HSE06+SOC）。孤对电子价带谷为图 7 中最高的那个。
      Table5_SnSb_vs_SnBi_valleys.csv    表 5 Sn₂Sb₂Te₅ 与 Sn₂Bi₂Te₅ 中 Γ 处最低导带态与价带顶附近各态的能量（相对各自价带顶，meV）与主要成分（%）。前两行之差即 Γ 处的反转带隙。
      Table6_Seebeck_300K.csv    表 6 300 K 面内 S（µV/K；箭头左为 PBE + BoltzTraP2，右为 HSE 估计，* 为暂定值）与孤对电子态承担的电导份额（HSE，3×10¹⁹ cm⁻³）。p 型计入阳离子 s ≥ 15% 的价带谷，n 型计入 Γ 处的导带谷；逐谷数值见 data/Fig8_Seebeck/。
      Table7_S_T_fit.csv    表 7 实验对照：由约 300 K 的实验 S 反推的净载流子浓度，以及 300–620 K 的最大偏差（计算 − 实验，µV/K）。
      Table8_lowest_formation_energies.csv    表 8 D、O 中各类缺陷最低位点的中性形成能（eV），从低到高排列；括号内为名义电荷。
      Table9_defects_D_O_L.csv    表 9 三种结构中各类缺陷的最低中性形成能（eV）。D、O 取富 Te 端，L 取富 Te 顶点；L 的计算设置不同，只比较排序与量级。
      Table10_conduction_type.csv    表 10 退火前后的主导缺陷与导电类型。

约定：能量单位 eV（另注明者除外），S 单位 µV/K，载流子浓度单位 cm^-3（正为空穴、负为电子），
k 点坐标为倒格矢分数坐标；谷的名称为所在高对称点或高对称线的标准记号（Σ：Γ–M，R：A–L，Δ：Γ–A，Λ：Γ–K，
Q：A–H，T：M–K；同一条线上的几个谷按离 Γ–A 轴由近到远加下标，如 R₁、R₂），见报告 1.2 节；能带 CSV 中 band_N 为 VASP 能带序号（SOC，_VB_top 为价带顶，_CB_bottom 为导带底）。
CSV 为 UTF-8（带 BOM），可直接用 Excel、Origin 打开。

生成脚本（在仓库中）：10_脚本/paper_figures.py（图与源数据）、10_脚本/multivalley_seebeck.py（S 的模型）、
10_脚本/build_paper_report.py（本压缩包）。
