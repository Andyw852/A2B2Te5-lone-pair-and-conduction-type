﻿A₂B₂Te₅ 的 HSE06+SOC 能带（专题），2026-11-04
=====================================================
HSE能带专题.html          报告（图片用相对路径，需与 figures/ 同目录）
HSE能带专题_单文件.html    同上，图片已嵌入，可单独转发
figures/png/  figures/pdf/  图 H1–H9（600 dpi PNG 与矢量 PDF），文件名即图号
data/<图目录>/             每幅图的源数据（CSV，UTF-8），目录与图的对应见 data/作图数据索引.csv
data/tables/               正文表 1–4
作图数据/<图目录>.xlsx      同样的数据，每幅图一个 Excel；第一页“说明”为数据来源、处理与画法

全部为 HSE06+SOC，只有图 H9（SOC 机制）目前是 PBE：HSE 不加 SOC 的计算见仓库 22_能带基准_1-0/SOC机制检验_HSE/。
能量零点为真实价带顶；Sn 系的孤对电子谷取镜面内三维搜索的真实极大。
程序：10_脚本/hse_band_figures.py、10_脚本/build_hse_bands_report.py、10_脚本/soc_mechanism.py
