﻿Pb₂Bi₂Te₅ 样品的 Seebeck 系数为什么最高：专题说明与作图数据（2026-11-11）

报告.html            报告（图片从 figures/png 读取，请整体解压后打开）
报告_单文件.html     同一报告，图片已嵌入，可单独打开或转发
figures/png、pdf     图 1–4（600 dpi PNG 与矢量 PDF）
data/<图>/           每幅图的源数据（CSV，UTF-8 带 BOM）
作图数据/<图>.xlsx   同样的数据，每幅图一个 Excel，第一页“说明”写明每个表的内容

Fig1_measured_S_PF/
  measured_T_sigma_S_PF.csv  四个样品的实验 T、σ、S（实验原始表），功率因子 S²σ 由同一行的 S 与 σ 相乘得到。
  Hall_room_temperature.csv  室温霍尔（实验原始表）。Pb₂Sb₂Te₅、Sn₂Sb₂Te₅ 的霍尔被仪器标红。
Fig2_same_concentration/
  S_at_same_concentration_300K.csv  300 K、相同载流子浓度下的 |S|：BoltzTraP2（PBE+SOC：bt2_pbe_dense；HSE06+SOC：c8_hse_dense，mult 60），常数弛豫时间、不加剪刀，浓度方向在化学势网格上按 log|N| 线性取值。
Fig3_concentration_and_mu/
  Pb2Bi2Te5_S_vs_electron_conc_300K.csv  Pb₂Bi₂Te₅ 的 n 型 |S|（300 K）随电子浓度，两种泛函的 BoltzTraP2。实验点：霍尔浓度 8.11×10¹⁹、约 302 K 的 S。
  Pb2Bi2Te5_mu_300K_PBE.csv  300 K 的化学势 µ（BoltzTraP2，对齐到能带路径的真实价带顶），以及 µ 高出导带底多少。
  Pb2Bi2Te5_PBE+SOC_bands.csv  Pb₂Bi₂Te₅ 的 PBE+SOC 路径能带（价带顶以下 6 条、以上 6 条），能量相对价带顶。
Fig4_Hall_2x2/
  Hall_and_S_by_site.csv  四个样品的室温霍尔浓度与约 300 K 的 S（实验），按 A 位（Sn、Pb）× B 位（Sb、Bi）排列。

数值全部来自已有计算（BoltzTraP2：PBE+SOC bt2_pbe_dense、HSE06+SOC c8_hse_dense）与实验原始数据，不做模型或估计。
生成程序（仓库中）：10_脚本/report_pbbi_high_S.py
